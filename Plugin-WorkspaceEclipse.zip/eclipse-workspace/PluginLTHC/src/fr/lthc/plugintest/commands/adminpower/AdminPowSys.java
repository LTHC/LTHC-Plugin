package fr.lthc.plugintest.commands.adminpower;

import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import fr.lthc.plugintest.PluginTestMain;

public class AdminPowSys implements CommandExecutor {

	private PluginTestMain main;
	
	public AdminPowSys(PluginTestMain pluginTestMain) {
		this.main = pluginTestMain;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(cmd.getName().equalsIgnoreCase("adminpower"))
		{
			if(sender instanceof Player)
			{
				Player p = (Player) sender;
				if(main.getConfig().getBoolean("adminpower.active") == true)
				{
					Inventory inv = Bukkit.createInventory(null, 27, "§8Inventaire ~LTHC~");
					
					ItemStack itEnder = new ItemStack(Material.ENDER_PEARL);
					ItemMeta itEnderM = itEnder.getItemMeta();
					itEnderM.setDisplayName("§cRandom §aTP");
					itEnder.setItemMeta(itEnderM);
					
					ItemStack itMap = new ItemStack(Material.EMPTY_MAP);
					ItemMeta itMapM = itMap.getItemMeta();
					itMapM.setDisplayName("§aRandom Passive §cMob Summon");
					itMap.setItemMeta(itMapM);
					
					inv.setItem(main.getConfig().getInt("events.invpos.summon"), itMap);
					inv.setItem(main.getConfig().getInt("events.invpos.rtp"), itEnder);
					
					ItemStack itcmd1 = new ItemStack(Material.COMMAND);
					ItemMeta itcmd1M = itcmd1.getItemMeta();
					itcmd1M.setDisplayName("§cRandChest");
					itcmd1.setItemMeta(itcmd1M);
					
					ItemStack itcmd2 = new ItemStack(Material.COMMAND);
					ItemMeta itcmd2M = itcmd2.getItemMeta();
					itcmd2M.setDisplayName("§cDist");
					itcmd2.setItemMeta(itcmd2M);
					
					inv.setItem(main.getConfig().getInt("adminpower.invpos.randchest"), itcmd1);
					inv.setItem(main.getConfig().getInt("adminpower.invpos.dist"), itcmd2);
					
					p.openInventory(inv);
					
					return true;
				}
				p.sendMessage("[PluginTest:PluginConfig] La commande adminpower est actuellement desactive");
				return true;
			}
			System.out.println("[PluginTest:Plugin:ErrorOfSender] Le 'sender' de cette commande n'est pas l'instance d'un joueur");
			return true;
		}
		return false;
	}
	
	
}
