package fr.lthc.plugintest;

import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class PluginTestEvents implements Listener {
	
	private PluginTestMain main;
	
	public PluginTestEvents(PluginTestMain pluginTestMain) {
		this.main = pluginTestMain;
	}

	@EventHandler
	public void onInteract(PlayerInteractEvent e)
	{
		Player p = e.getPlayer();
		Action a = e.getAction();
		ItemStack it = e.getItem();
		
		if(it == null) {
			return;
		}
		else if(it.getType() == Material.COMPASS)
		{
			if(a == Action.RIGHT_CLICK_AIR || a == Action.LEFT_CLICK_AIR)
			{
				Inventory inv = Bukkit.createInventory(null, 9, "§8Inventaire ~LTHC~");
				
				ItemStack itEnder = new ItemStack(Material.ENDER_PEARL);
				ItemMeta itEnderM = itEnder.getItemMeta();
				itEnderM.setDisplayName("§cRandom §aTP");
				itEnder.setItemMeta(itEnderM);
				
				ItemStack itMap = new ItemStack(Material.EMPTY_MAP);
				ItemMeta itMapM = itMap.getItemMeta();
				itMapM.setDisplayName("§aRandom Passive §cMob Summon");
				itMap.setItemMeta(itMapM);
				
				inv.setItem(main.getConfig().getInt("events.invpos.summon"), itMap);
				inv.setItem(main.getConfig().getInt("events.invpos.rtp"), itEnder);
				
				p.openInventory(inv);
			}
		}
	}
	
	@EventHandler
	public void onClick(InventoryClickEvent e)
	{
		Inventory inv = e.getInventory();
		Player p = (Player) e.getWhoClicked();
		ItemStack current = e.getCurrentItem();
		
		if(current == null)
		{
			return;
		}
		
		if(inv.getName().equalsIgnoreCase("§8Inventaire ~LTHC~"))
		{
			if(current.getType() == Material.EMPTY_MAP && current.hasItemMeta() && current.getItemMeta().hasDisplayName() && current.getItemMeta().getDisplayName() == "§aRandom Passive §cMob Summon")
			{
				p.closeInventory();
				Random r = new Random();
				int summon = 0 + r.nextInt(4);
				if(summon == 1)
				{
					Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "summon Cow " + p.getLocation().getX() + " " + p.getLocation().getY() + " " + p.getLocation().getZ());
				}
				if(summon == 2)
				{
					Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "summon Pig " + p.getLocation().getX() + " " + p.getLocation().getY() + " " + p.getLocation().getZ());
				}
			}
			if(current.getType() == Material.ENDER_PEARL && current.hasItemMeta() && current.getItemMeta().hasDisplayName() && current.getItemMeta().getDisplayName() == "§cRandom §aTP")
			{
				p.closeInventory();
				Random r = new Random();
				
				int xmap = main.getConfig().getInt("events.rtp.x");
				int zmap = main.getConfig().getInt("events.rtp.z");
				
				double x = 0 + r.nextInt(2*xmap) - xmap;
				double z = 0 + r.nextInt(2*zmap) - zmap;
				double y = 0 + p.getWorld().getHighestBlockAt(new Location(p.getWorld(), x, 0, z)).getY() + 2;
				
				p.teleport(new Location(p.getWorld(), x, y, z));
			}
			if(current.getType() == Material.COMMAND && current.hasItemMeta() && current.getItemMeta().hasDisplayName() && current.getItemMeta().getDisplayName() == "§cRandChest")
			{
				p.closeInventory();
				Bukkit.dispatchCommand(p, "randchest");
			}
			if(current.getType() == Material.COMMAND && current.hasItemMeta() && current.getItemMeta().hasDisplayName() && current.getItemMeta().getDisplayName() == "§cDist")
			{
				p.closeInventory();
				Bukkit.dispatchCommand(p, "dist");
			}
		}
	}

}
